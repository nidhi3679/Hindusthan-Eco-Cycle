// src/data/teamData.js
const teamData = {
    "4DM21CS017": {
      name: "DEEKSHITH",
      role: "Software Development Intern",
      photo: "/images/Deekshith.jpg",
    },
    "4DM21AI063": {
      name: "VACHAN KUMAR",
      role: "Software Development Intern",
      photo: "/images/vachan.jpg",
    },
    "4DM21CS023": {
      name: "Joel Yenosh Dsouza",
      role: "Software Development Intern",
      photo: "/images/joel.jpg",
    },
    "4DM21CS036": {
        name: "Nidhi",
        role: "Software Development Intern",
        photo: "/images/nidhi.jpg",
      },
      "4DM21CS041": {
        name: "Riya Sonal Nazareth",
        role: "Software Development Intern",
        photo: "/images/Ria.jpg",
      },
      "4DM21CS051": {
        name: "Sinchana S",
        role: "Software Development Intern",
        photo: "/images/sinchana.jpg",
      },
      "4DM21CS061": {
        name: "Vimarsha Devadiga",
        role: "Software Development Intern",
        photo: "/images/Vimarsha.jpg",
      },
  };
  
  export default teamData;
  