import React from 'react'

function ErrorElement() {
  return (
    <div>404 page tikiji</div>
  )
}

export default ErrorElement